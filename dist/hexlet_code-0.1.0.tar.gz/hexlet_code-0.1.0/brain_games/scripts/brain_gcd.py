#! /usr/bin/env python3

from brain_games.gcd_logic import gcd_calculation


def main():
    gcd_calculation()


if __name__ == "__main__":
    main()