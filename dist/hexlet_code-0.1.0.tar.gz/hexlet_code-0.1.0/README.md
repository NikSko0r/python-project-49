### Hexlet tests and linter status:
[![Actions Status](https://github.com/NikSko0r/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/NikSko0r/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/650bf104e99f51840b87/maintainability)](https://codeclimate.com/github/NikSko0r/python-project-49/maintainability)

[Asciinema for brain-even](https://asciinema.org/a/629244)