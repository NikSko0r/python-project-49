#! /usr/bin/env python3
def welcome_brain_games():
    print(f'Welcome to Brain Games!')

def main():
    welcome_brain_games()

if __name__ == '__main__':
    welcome_brain_games()
