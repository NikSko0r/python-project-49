#! /usr/bin/env python3

from brain_games.progression_logic import progressions_calculate


def main():
    progressions_calculate()


if __name__ == "__main__":
    main()
